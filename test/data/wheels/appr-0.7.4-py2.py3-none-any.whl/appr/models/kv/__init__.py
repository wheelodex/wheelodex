import os

APPR_KV_PREFIX = os.getenv("APPR_KV_PREFIX", "appr/packages/")
