from __future__ import absolute_import, division, print_function

from appr.api.app import create_app

app = create_app()
