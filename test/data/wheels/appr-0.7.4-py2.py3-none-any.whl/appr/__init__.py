# -*- coding: utf-8 -*-
import platform

__author__ = 'Antoine Legrand'
__email__ = '2t.antoine@gmail.com'
__version__ = '0.7.4'

SYSTEM = platform.system().lower()
